
import { useState, useEffect } from 'react';
import { QRCode } from 'react-qrcode-logo';
import { useRouter } from 'next/router';

export default function Home() {
  const [url, setUrl] = useState('');
  const [qrUrl, setQrUrl] = useState('');
  const [trackingLinks, setTrackingLinks] = useState({});
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const query = new URLSearchParams(window.location.search);
      const trackingId = query.get('redirect');
      if (trackingId) {
        const storedLinks = JSON.parse(localStorage.getItem('qrmy_links') || '{}');
        const targetUrl = storedLinks[trackingId];
        if (targetUrl) {
          window.location.replace(targetUrl);
        }
      }
    }
  }, [router]);

  const handleGenerate = () => {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      alert('Please enter a valid URL starting with http:// or https://');
      return;
    }

    const trackingId = Math.random().toString(36).substring(2, 10);
    const baseUrl = `${window.location.origin}${window.location.pathname}`;
    const shortUrl = `${baseUrl}?redirect=${trackingId}`;

    const updatedLinks = { ...trackingLinks, [trackingId]: url };
    setTrackingLinks(updatedLinks);
    localStorage.setItem('qrmy_links', JSON.stringify(updatedLinks));

    setQrUrl(shortUrl);
  };

  return (
    <div className="min-h-screen bg-white text-blue-800 flex flex-col items-center justify-center px-4">
      <h1 className="text-4xl font-bold mb-4">Qrmy</h1>
      <p className="mb-8 text-center max-w-md">
        Generate QR codes that track how many times they’ve been scanned.
      </p>

      <div className="flex flex-col gap-4 w-full max-w-md">
        <input
          type="text"
          placeholder="Enter a URL (https://example.com)"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="border border-blue-300 px-4 py-2 rounded"
        />
        <button
          onClick={handleGenerate}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Generate QR Code
        </button>
      </div>

      {qrUrl && (
        <div className="mt-8 text-center">
          <QRCode value={qrUrl} size={200} />
          <p className="mt-4 text-sm">Scan will redirect to: <br />
            <a href={qrUrl} className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">{qrUrl}</a>
          </p>
        </div>
      )}
    </div>
  );
}
